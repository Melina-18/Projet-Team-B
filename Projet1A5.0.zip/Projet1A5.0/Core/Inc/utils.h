/*
 * utils.h
 *
 *  Created on: May 5, 2025
 *      Author: Utilisateur
 */

#ifndef INC_UTILS_H_
#define INC_UTILS_H_

//================================
//Importation des librairies
//================================

#include "main.h"
#include "fonts.h"
#include "ssd1315.h"
#include "RC522.h"
#include <stdio.h>

//===============================================================
//Définition des ports, des pins et des variables
//===============================================================

#define GPIOLED GPIOB
#define GPIO_PIN_LED1 GPIO_PIN_2
#define GPIO_PIN_LED2 GPIO_PIN_1
#define GPIO_PIN_LED3 GPIO_PIN_15
#define GPIO_PIN_LEDRED GPIO_PIN_14
#define GPIOButton GPIOB
#define GPIO_PIN_ButtonValid GPIO_PIN_13
#define GPIO_PIN_ButtonLeft GPIO_PIN_10
#define GPIO_PIN_ButtonRight GPIO_PIN_4
#define GPIO_PIN_ButtonReset GPIO_PIN_5
#define NUMBER_OF_ROOMS 6

//===============================================================
//Fonctions des composants
//===============================================================

void screen_update();
void Card_READ(void);
void room_update(void);
void add_character(char *character);
void led(void);
void setServo(int angle);

//===============================================================
//Fonctions du jeux
//===============================================================

void loop();
void test(void);
void validation(void);
int verification(void);
void aff();
void reset(void);


#endif /* INC_UTILS_H_ */
