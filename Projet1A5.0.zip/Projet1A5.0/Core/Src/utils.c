
#include "utils.h"

//===============================================================
//Définition des variables
//===============================================================

static int i=0;
char* pieces[6]={"salon","cuisine","bibliot","bureau","chambre","couloir"};
char* personages[6]={"","","","","",""};
int nb_personages[6]={0,0,0,0,0,0};
int timer=0;
static int button_pressed=0;
int Card_Passed=0;
int old_str[5]={0,0,0,0,0};
char* perso;
int pos=20;
uint8_t status1;
uint8_t status2;
uint8_t str[16]={0};
uint8_t sNum[5];
static int level=0;
static int p=0;


//===============================================================
//Fonctions des composants
//===============================================================

//screen_update : Met à jour l'écran
void screen_update()
{	if (button_pressed==1){
		char buffer[16]={0};
		ssd1315_Clear(SSD1315_COLOR_BLACK);
		snprintf(buffer,16,"%s ",(pieces[i]));
		ssd1315_Draw_String(0,0,buffer,&Font_11x18);
		int len=strlen(personages[i]);
		for (int n=0;n<len;n++){
			snprintf(buffer,16,"%c ",(personages[i][n]));
			ssd1315_Draw_String(7*n,pos,buffer,&Font_7x10);
			ssd1315_Refresh();
			printf("%c \n\r",personages[i][n]);
			}
		pos=20;
		ssd1315_Refresh();
	}
	if (Card_Passed==1){
		Card_Passed=0;
		char buffer[16]={0};
		snprintf(buffer,16,"%s ",(pieces[i]));
		ssd1315_Draw_String(0,0,buffer,&Font_11x18);
		snprintf(buffer,16,"%s ",perso);
		ssd1315_Draw_String(0,10+(10*nb_personages[i]),buffer,&Font_7x10);
		ssd1315_Refresh();}
}

//room_update : Changement de pièce lorsque l'on appuie sur le bouton gauche ou droite
void room_update(void)
{
	if (HAL_GPIO_ReadPin(GPIOButton,GPIO_PIN_ButtonRight)==0)
	{
			if (button_pressed==0)
			{
				i=(i+1)%NUMBER_OF_ROOMS;
				button_pressed=1;

			}
	}
	else if (HAL_GPIO_ReadPin(GPIOButton,GPIO_PIN_ButtonLeft)==0)
	{
			if (button_pressed==0)
			{
				if (i==0){i=5;}
				else{i=i-1;}
			button_pressed=1;
			}
	}
	else{ button_pressed=0;}

}

//Card_READ : Lis les informations de la carte ou d'un tag et l'ajoute sur l'écran
void Card_READ(void)
{
	//Les trois porchaines lignes suffisent pour
	status1=MFRC522_Request(PICC_REQIDL,str);
	status2=MFRC522_Anticoll(str);
	memcpy(sNum,str,5);
	if (status1==0 && status2==0 && Read_MFRC522(0x37)==146  && (str[0]!=old_str[0] ||  str[1]!=old_str[1] || str[2]!=old_str[2] || str[3]!=old_str[3] || str[4]!=old_str[4])) // Vérifie que le capteur fonctionne correctement et que la valeur est différente de la précédente
	{	old_str[0]=str[0];
		old_str[1]=str[1];
		old_str[2]=str[2];
		old_str[3]=str[3];
		old_str[4]=str[4];
		Card_Passed=1;
		/*printf("sNum : %d %d %d %d %d\n \r",sNum[0],sNum[1],sNum[2],sNum[3],sNum[4]);
		printf("str : %d %d %d %d %d\n \r",str[0],str[1],str[2],str[3],str[4]);
		printf("status1 : %d\r\n",status1);
		printf("status2 : %d\r\n",status2);
		printf("Serial Number : %d\r\n",Read_MFRC522(0x37));
		printf("\r\n");*/
		if (str[0]==218 && str[1]==232 && str[2]==60 && str[3]==77 && str[4]==67){
				printf("Clemence Montclar\r\n");
				add_character("Clemence ");
				perso="Clemence ";
				nb_personages[i]+=1;}

		if (str[0]==176 && str[1]==94 && str[2]==145 && str[3]==35 && str[4]==92){
				printf("Samuel Roche\r\n");
				add_character("Samuel ");
				perso="Samuel ";
				nb_personages[i]+=1;}

		if (str[0]==32 && str[1]==123 && str[2]==146 && str[3]==35 && str[4]==234){
				printf("Jules Martel\r\n");
				add_character("Jules ");
				perso="Jules ";
				nb_personages[i]+=1;}

		if (str[0]==240 && str[1]==25 && str[2]==131 && str[3]==35 && str[4]==73){
				printf("Louise Montclar\r\n");
				add_character("Louise ");
				perso="Louise ";
				nb_personages[i]+=1;}

		if (str[0]==32 && str[1]==178 && str[2]==143 && str[3]==35 && str[4]==62){
				printf("Emile Lemoine\r\n");
				add_character("Emile ");
				perso="Emile ";
				nb_personages[i]+=1;}

		if (str[0]==48 && str[1]==63 && str[2]==145 && str[3]==35 && str[4]==189){
				printf("Agathe\r\n");
				add_character("Agathe ");
				perso="Agathe ";
				nb_personages[i]+=1;}

		/*if (str[0]==144 && str[1]==122 && str[2]==147 && str[3]==35 && str[4]==90){
				printf("DARDIER Jules\r\n");
				add_character("Jules");
				nb_personages[i]+=1;}

		if (str[0]==176 && str[1]==141 && str[2]==145 && str[3]==35 && str[4]==143){
				printf("ZEE William\r\n");
				add_character("William");
				nb_personages[i]+=1;}

		if (str[0]==32 && str[1]==252 && str[2]==146 && str[3]==35 && str[4]==109){
				printf("GUEYE Idrissa\r\n");
				add_character("Idrissa");
				nb_personages[i]+=1;}

		if (str[0]==48 && str[1]==187 && str[2]==139 && str[3]==35 && str[4]==35){
				printf("ELBAHI Walid\r\n");
				add_character("Walid ");
				perso="Walid";
				nb_personages[i]+=1;}

		if (str[0]==240 && str[1]==105 && str[2]==145 && str[3]==35 && str[4]==43){
				printf("DRAMERA Hadi\r\n");
				add_character("Hadi ");
				perso="Hadi";
				nb_personages[i]+=1;}*/
	}
}

//setServo : Permet de contrôler l'angle du servo-moteur, entre 0° et 120°
void setServo(int angle)
{
	int pmax = 1900;
	int pmin = 1500;
	int amax = 120;
	float r = (float)angle/amax;
	int p = pmin+(int)((pmax - pmin)*r);
	TIM2->CCR1 = p;
}

//led : Allume ou éteint les leds en fonction de la valeur de level
void led(void)
{
	switch (level)
	{
	case 0:
	{
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED1,GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED2,GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED3,GPIO_PIN_RESET);
	}break;
	case 1:
	{
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED1,GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED2,GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED3,GPIO_PIN_RESET);
	}break;
	case 2:
		{
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED1,GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED2,GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED3,GPIO_PIN_RESET);
		}break;
	case 3:
		{
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED1,GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED2,GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED3,GPIO_PIN_SET);
		}break;
	}
}

//test : Test tous les composants en même temps pour vérifier leurs on fonctionnement
void test (void){
	char buffer[16]={0};
	ssd1315_Clear(SSD1315_COLOR_BLACK);
	snprintf(buffer,16,"test");
	ssd1315_Draw_String(0,0,buffer,&Font_7x10);
	ssd1315_Refresh();
	if(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_ButtonValid)==GPIO_PIN_RESET){
		printf("button VALID pressed \n\r");
	}
	if(HAL_GPIO_ReadPin(GPIOButton,GPIO_PIN_ButtonReset)==GPIO_PIN_RESET){
			printf("button RESET pressed \n\r");
		}
	if(HAL_GPIO_ReadPin(GPIOButton,GPIO_PIN_ButtonRight)==GPIO_PIN_RESET){
				printf("button RIGHT pressed \n\r");
			}
	if(HAL_GPIO_ReadPin(GPIOButton,GPIO_PIN_ButtonLeft)==GPIO_PIN_RESET){
					printf("button LEFT pressed \n\r");
				}
	HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED1,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED2,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED3,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LEDRED,GPIO_PIN_SET);
	Card_READ();
	setServo(120);
}


//===============================================================
//Fonctions du jeux
//===============================================================

//loop : Le coeur du jeu
void loop()
{
	screen_update();
	Card_READ();
	room_update();
	led();
	validation();
	if(HAL_GPIO_ReadPin(GPIOButton,GPIO_PIN_ButtonReset)==GPIO_PIN_RESET)
		{
			reset();
		}
	if (level==3)
	{
		setServo(120);
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED1,GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED2,GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED3,GPIO_PIN_SET);
		HAL_Delay(1000);
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED1,GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED2,GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LED3,GPIO_PIN_RESET);
	}
}

//add_character : Ajoute un personnage dans la pièce associé
void  add_character(char *character){
  int len=strlen(character);
  int len2=strlen((personages[i]));
  char buf[len+len2+1];
  strcpy(buf,(personages[i]));
  for( int n=0;n<len;n++){
	 buf[n+len2]=character[n];
 }
  buf[len+len2+2]=0;
personages[i]= strdup(buf);
}

//validation : Une fois le bouton de validation appuyer, vérifie par rapport à la bonne réponse et du niveau actuelle
void validation(void)
{
	if (HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_ButtonValid)==GPIO_PIN_RESET)
	{
		aff();
		//printf("p=%d\r\n",verification());
		p=0;
		if (level==0 && verification()==6)//Vérifie l'acte
		{
			level=1;
			led();
			reset();
		}

		else if (level==1 && verification()==6)
		{
			level=2;
			led();
			reset();
		}

		else if (level==2 && verification()==6)
		{
			level=3;
			led();
			reset();
		}

		else
		{
			HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LEDRED,GPIO_PIN_SET);
			HAL_Delay(1000);
			HAL_GPIO_WritePin(GPIOLED,GPIO_PIN_LEDRED,GPIO_PIN_RESET);
			reset();
		}

	}
}

//verification : Vérifie par rapport à chaque pièce et la réponse
int verification(void)
{
	switch (level){
		case 0:
			for (int i = 0; i < 6; i++)
			{
				if (strcmp(personages[i],"Clemence ")==0 && i==0)
	        	{
	            	printf("salon valide\n\r");
	            	p+=1;
	        	}
	        	else if (strcmp(personages[i],"Agathe ")==0 && i==1)
	        	{
	            	printf("cuisine valide\n\r");
	            	p+=1;
	        	}
	        	else if (strcmp(personages[i],"Jules ")==0 && i==2)
	        	{
	        		printf("bibliotheque valide\n\r");
	        		p+=1;
	        	}
	        	else if (strcmp(personages[i],"Emile ")==0 && i==3)
	        	{
	        		printf("bureau valide\n\r");
	        		p+=1;
	        	}
	        	else if (strcmp(personages[i],"Louise ")==0 && i==4)
	        	{
	        		printf("chambre valide\n\r");
	        		p+=1;
	        	}
	        	else if (strcmp(personages[i],"Samuel ")==0 && i==5)
	        	{
	        		printf("couloir valide\n\r");
	        		p+=1;
	        	}

		    }break;
	case 1:
		for (int i = 0; i < 6; i++)
			{
		        if (strcmp(personages[i],"Clemence ")==0 && i==0)
		        {
		            printf("salon valide\n\r");
		            p+=1;
		        }
		        else if (strcmp(personages[i],"Agathe ")==0 && i==1)
		        {
		            printf("cuisine valide\n\r");
		            p+=1;
		        }
		        else if ((strcmp(personages[i],"Jules Samuel ")==0|| strcmp(personages[i],"Samuel Jules ")==0) && i==2)
		        {
		        	printf("bibliotheque valide\n\r");
		        	p+=1;
		        }
		        else if (strcmp(personages[i],"")==0 && i==3)
		        {
		        	printf("bureau valide\n\r");
		        	p+=1;
		        }
		        else if (strcmp(personages[i],"Louise ")==0 && i==4)
		        {
		        	printf("chambre valide\n\r");
		        	p+=1;
		        }
		        else if (strcmp(personages[i],"Emile ")==0 && i==5)
		        {
		        	printf("couloir valide\n\r");
		        	p+=1;
		        }
			}break;
	case 2:
			for (int i = 0; i < 6; i++)
			{
			     if (strcmp(personages[i],"")==0 && i==0)
			     {
			        printf("salon valide\n\r");
			        p+=1;
			     }
			     else if (strcmp(personages[i],"Agathe ")==0 && i==1)
			     {
			         printf("cuisine valide\n\r");
			         p+=1;
			     }
			     else if ((strcmp(personages[i],"Jules ")==0) && i==2)
			     {
			         printf("bibliotheque valide\n\r");
			         p+=1;
			     }
			     else if (strcmp(personages[i],"Clemence ")==0 && i==3)
			     {
			         printf("bureau valide\n\r");
			         p+=1;
			     }
			     else if (strcmp(personages[i],"Louise ")==0 && i==4)
			     {
			         printf("chambre valide\n\r");
			         p+=1;
			     }
			     else if ((strcmp(personages[i],"Emile Samuel ")==0||strcmp(personages[i],"Samuel Emile ")==0) && i==5)
			     {
			         printf("couloir valide\n\r");
			         p+=1;
			     }
			}break;

	}
	return p;
}

//aff : Affiche les personnages dans chaque pièce
void aff() {
    for (int i = 0; i < 6; i++) {
        if (personages[i]) {
            printf("personages[%d] = \"%s\"\n\r", i, personages[i]);
        } else {
            printf("personages[%d] est vide ou NULL\n\r", i);
        }
    }
}

//reset : Enlève les personnages dans chaque pièce
void reset(void)
{
	for (int i=0;i<6;i++){
		personages[i]="";
		nb_personages[i]=0;}
	old_str[0]=0;
	old_str[1]=0;
	old_str[2]=0;
	old_str[3]=0;
	old_str[4]=0;
	HAL_Delay(1000);
}
